﻿

namespace Antijank.Debugging {

  
  public enum CorDebugThreadState {

    THREAD_RUN,

    THREAD_SUSPEND

  }

}