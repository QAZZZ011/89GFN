using System.Diagnostics.CodeAnalysis;


namespace Antijank.Interop {

  
  [SuppressMessage("ReSharper", "InconsistentNaming")]
  public abstract class CONTEXT { }

}