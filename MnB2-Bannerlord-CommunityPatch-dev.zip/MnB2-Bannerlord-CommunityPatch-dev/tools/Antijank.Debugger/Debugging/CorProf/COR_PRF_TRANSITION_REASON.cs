﻿

namespace Antijank.Debugging {

  
  public enum COR_PRF_TRANSITION_REASON {

    COR_PRF_TRANSITION_CALL,

    COR_PRF_TRANSITION_RETURN

  }

}