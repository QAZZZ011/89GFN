﻿

namespace Antijank.Debugging {

  
  public enum COR_PRF_RUNTIME_TYPE {

    COR_PRF_DESKTOP_CLR = 1,

    COR_PRF_CORE_CLR

  }

}