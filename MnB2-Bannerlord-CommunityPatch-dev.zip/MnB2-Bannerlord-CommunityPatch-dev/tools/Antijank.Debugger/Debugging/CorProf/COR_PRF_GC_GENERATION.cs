﻿

namespace Antijank.Debugging {

  
  public enum COR_PRF_GC_GENERATION {

    COR_PRF_GC_GEN_0,

    COR_PRF_GC_GEN_1,

    COR_PRF_GC_GEN_2,

    COR_PRF_GC_LARGE_OBJECT_HEAP

  }

}