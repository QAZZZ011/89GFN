namespace CommunityPatch.Patches.Perks.Cunning.Scouting {
  public sealed class NavigatorPatch : PartySpeedSubPatch<NavigatorPatch> {
    public NavigatorPatch() : base("MxSalCZz") { }
  }
}
