﻿

namespace Antijank.Debugging {

  
  public enum CLRDataSourceType {

    CLRDATA_SOURCE_TYPE_INVALID

  }

}