namespace Antijank.Interop {

  public enum CorInfoRegionKind
  {
    None,
    Hot,
    Cold,
    Jit,
  };

}