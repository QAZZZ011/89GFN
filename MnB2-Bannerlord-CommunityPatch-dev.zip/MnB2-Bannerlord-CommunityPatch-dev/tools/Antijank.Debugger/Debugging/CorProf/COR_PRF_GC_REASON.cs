﻿

namespace Antijank.Debugging {

  
  public enum COR_PRF_GC_REASON {

    COR_PRF_GC_INDUCED = 1,

    COR_PRF_GC_OTHER = 0

  }

}