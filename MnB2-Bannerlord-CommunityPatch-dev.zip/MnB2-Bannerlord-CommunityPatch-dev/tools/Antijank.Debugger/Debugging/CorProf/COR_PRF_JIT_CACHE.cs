﻿

namespace Antijank.Debugging {

  
  public enum COR_PRF_JIT_CACHE {

    COR_PRF_CACHED_FUNCTION_FOUND,

    COR_PRF_CACHED_FUNCTION_NOT_FOUND

  }

}