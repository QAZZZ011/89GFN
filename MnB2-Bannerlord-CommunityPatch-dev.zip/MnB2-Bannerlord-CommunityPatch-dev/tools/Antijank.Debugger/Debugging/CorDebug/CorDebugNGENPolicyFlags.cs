

namespace Antijank.Debugging {

  
  public enum CorDebugNGENPolicyFlags {

    DISABLE_LOCAL_NIC = 1

  }

}