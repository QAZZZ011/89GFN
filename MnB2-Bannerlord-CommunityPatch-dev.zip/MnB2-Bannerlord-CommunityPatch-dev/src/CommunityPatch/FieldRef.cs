namespace CommunityPatch {

  public delegate ref TField FieldRef<in T, TField>(T o);

}