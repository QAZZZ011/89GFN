﻿

namespace Antijank.Debugging {

  
  public enum CorDebugHandleType {

    HANDLE_STRONG = 1,

    HANDLE_WEAK_TRACK_RESURRECTION

  }

}