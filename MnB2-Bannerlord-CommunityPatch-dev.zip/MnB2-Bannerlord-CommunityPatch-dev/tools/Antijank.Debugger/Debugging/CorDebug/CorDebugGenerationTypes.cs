

namespace Antijank.Debugging {

  
  public enum CorDebugGenerationTypes {

    Gen0 = 0,

    Gen1 = 1,

    Gen2 = 2,

    LOH = 3,

    Invalid = -1

  }

}