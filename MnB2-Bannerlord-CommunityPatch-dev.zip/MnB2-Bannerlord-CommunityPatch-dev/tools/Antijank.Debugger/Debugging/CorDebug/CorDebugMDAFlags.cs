﻿

namespace Antijank.Debugging {

  
  public enum CorDebugMDAFlags {

    MDA_FLAG_SLIP = 2

  }

}