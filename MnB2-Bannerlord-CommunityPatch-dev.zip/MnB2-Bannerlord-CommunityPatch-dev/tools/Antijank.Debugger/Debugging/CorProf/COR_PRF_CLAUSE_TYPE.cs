﻿

namespace Antijank.Debugging {

  
  public enum COR_PRF_CLAUSE_TYPE {

    COR_PRF_CLAUSE_NONE,

    COR_PRF_CLAUSE_FILTER,

    COR_PRF_CLAUSE_CATCH,

    COR_PRF_CLAUSE_FINALLY

  }

}