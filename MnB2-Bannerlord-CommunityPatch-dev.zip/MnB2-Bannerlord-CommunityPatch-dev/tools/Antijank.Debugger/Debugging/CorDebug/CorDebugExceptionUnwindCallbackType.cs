﻿

namespace Antijank.Debugging {

  
  public enum CorDebugExceptionUnwindCallbackType {

    DEBUG_EXCEPTION_UNWIND_BEGIN = 1,

    DEBUG_EXCEPTION_INTERCEPTED

  }

}