

namespace Antijank.Debugging {

  
  public enum CorDebugGCType {

    CorDebugWorkstationGC = 0,

    CorDebugServerGC = 1

  }

}