﻿

namespace Antijank.Debugging {

  
  public enum GcEvt_t {

    GC_MARK_END = 1,

    GC_EVENT_TYPE_MAX

  }

}