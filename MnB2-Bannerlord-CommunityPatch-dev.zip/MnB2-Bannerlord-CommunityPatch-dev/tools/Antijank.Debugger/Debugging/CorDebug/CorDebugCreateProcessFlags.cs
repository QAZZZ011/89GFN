﻿

namespace Antijank.Debugging {

  
  public enum CorDebugCreateProcessFlags {

    DEBUG_NO_SPECIAL_OPTIONS

  }

}