

namespace Antijank.Debugging {

  // ReSharper disable once IdentifierTypo // yes it should writable
  
  public enum SetWriteableMetadataUpdateMode {

    LegacyCompatPolicy,

    AlwaysShowUpdates

  }

}