namespace Antijank.Debugging {

  public enum CorSaveSize : uint {

    cssAccurate,

    cssQuick,

    cssDiscardTransientCAs

  }

}