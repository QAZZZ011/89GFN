﻿

namespace Antijank.Debugging {

  
  public enum CLRDataMethodDefinitionExtentType {

    CLRDATA_METHDEF_IL

  }

}