namespace CommunityPatch.Patches.Perks.Intelligence.Steward {
  public sealed class LogisticsExpertPatch : PartySpeedSubPatch<LogisticsExpertPatch> {
    public LogisticsExpertPatch() : base("6JaeM2p2") { }
  }
}
