namespace Antijank.Debugging {

  public enum CorSetEnC {

    MDUpdateENC = 1,

    MDUpdateFull,

    MDUpdateExtension,

    MDUpdateIncremental,

    MDUpdateDelta,

    MDUpdateMask

  }

}